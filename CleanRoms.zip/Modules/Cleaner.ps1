﻿# ============================================================
# CleanROMs v2.7
#
# Cleaner.ps1
#
# Genera el plan de limpieza
# ============================================================

# ============================================================
# Crea una acción
# ============================================================

function New-CleanAction {

    param(

        [Parameter(Mandatory)]
        [ValidateSet("KEEP","MOVE","DELETE","RENAME")]
        [string]$Action,

        [Parameter(Mandatory)]
        $Rom,

        [string]$Target = "",

        [string]$Reason = "",

        #
        # Si ya se calculó el hash de esta ROM de antemano (p.ej.
        # con Get-RomHashesParallel, al construir todo el plan de
        # golpe), se puede pasar aquí directamente para no volver
        # a leer y hashear el archivo por segunda vez. Si no se
        # indica, se calcula igual que siempre.
        #

        [string]$Hash = $null,

        #
        # Nombre real del sistema (p.ej. "snes"), cuando se conoce
        # con certeza en el punto donde se crea la acción (por
        # ejemplo, desde $group.System en Invoke-CleanPreview).
        # Se guarda tal cual en la acción para que Show-SystemSummary
        # no tenga que adivinarlo a partir de la ruta del archivo —
        # ese cálculo por ruta es justo el que fallaba con
        # Get-DuplicateTargetFolder cuando la ROM vivía en una
        # subcarpeta (ver sección 21 del manual). Opcional: si no
        # se indica, Show-SystemSummary recurre a ese mismo cálculo
        # por ruta como red de seguridad.
        #

        [string]$System = $null

    )

    if([string]::IsNullOrWhiteSpace($Hash))
    {
        $Hash = Get-RomHash -Path $Rom.FullPath
    }

    return [PSCustomObject]@{

        Action = $Action

        Rom = $Rom

        Source = $Rom.FullPath

        Target = $Target

        Reason = $Reason

        Hash = $Hash

        System = $System

        TimeStamp = Get-Date

        #
        # Nombres (solo el nombre de archivo, no la ruta completa)
        # de los archivos asociados que se movieron junto con esta
        # ROM (partida guardada, configuración de mando...), para
        # que "Deshacer la última limpieza" también pueda
        # devolverlos a su sitio. Se rellena durante la ejecución
        # (Executor.ps1), no aquí: en el momento de crear la
        # acción todavía no se ha movido nada.
        #

        AssociatedFiles = @()

    }

}

# ============================================================
# Genera el plan de limpieza
# ============================================================

# ============================================================
# Limpieza completa de ROMs para uno o varios sistemas
#
# Escanea, agrupa, decide, previsualiza, exporta el plan y
# (si se confirma) lo ejecuta. Se usa tanto para "limpiar un
# sistema" como para "limpiar TODOS los sistemas".
# ============================================================

function Invoke-RomCleaning {

    param(
        [Parameter(Mandatory)]
        [string]$Root,

        [Parameter(Mandatory)]
        [string[]]$SystemFolders
    )

    Write-Host ""

    Initialize-SevenZipSupport

    $groups = @()

    foreach($folder in $SystemFolders)
    {
        $systemName = Split-Path $folder -Leaf

        Write-Host ""
        Write-Host (T "scan.system" $systemName)
        Write-Host (T "scan.folder" $folder)

        if(!(Test-Path -LiteralPath $folder))
        {
            Write-Host "  -> Carpeta no encontrada, se omite." -ForegroundColor DarkYellow
            continue
        }

        $roms = @(Get-RomsFromFolder -Path $folder -SystemName $systemName)

        Write-Host (T "scan.romsFound" $roms.Count)

        if($roms.Count -eq 0)
        {
            continue
        }

        $roms = @(Update-NormalizedTitles $roms)

        $sysGroups = @(Group-Roms -Roms $roms -SystemName $systemName)

        Write-Host (T "scan.groupsFound" $sysGroups.Count)

        $groups += $sysGroups
    }

    Write-Host ""
    Write-Host "-----------------------------------------"
    Write-Host (T "scan.totalGroups" $groups.Count)
    Write-Host ""

    #--------------------------------------------------------------
    # Decision Engine + Cleaner
    #--------------------------------------------------------------

    if($groups.Count -eq 0)
    {
        Write-Host ""
        Write-Host (T "scan.noDuplicatesFound") -ForegroundColor Green
        Write-Host ""

        $actions = @()
    }
    else
    {
        $actions = @(Invoke-CleanPreview -Groups $groups -Root $Root)
    }

    #--------------------------------------------------------------
    # Construcción del plan
    #--------------------------------------------------------------

    $plan = Build-CleanPlan $actions

    #--------------------------------------------------------------
    # Validación
    #--------------------------------------------------------------

    Validate-CleanPlan $plan

    #--------------------------------------------------------------
    # Vista previa
    #--------------------------------------------------------------

    Show-CleanPreview $plan.Actions

    #--------------------------------------------------------------
    # Resumen
    #--------------------------------------------------------------

    Show-CleanSummary $plan

    #--------------------------------------------------------------
    # Exportar plan
    #--------------------------------------------------------------

    $exported = Export-CleanPlan `
        -Plan $plan `
        -OutputFolder (Join-Path $Root "Resultado") `
        -Rotate

    Write-Host ""
    Write-Host (T "plan.exportedTo")
    Write-Host "  - $($exported.Json)"
    Write-Host "  - $($exported.Csv)"
    Write-Host (T "plan.htmlHint" $exported.Html)

    #--------------------------------------------------------------
    # Confirmación
    #--------------------------------------------------------------

    if($plan.Actions.Count -eq 0)
    {
        Write-Host ""
        Write-Host (T "plan.nothingToExecute")
        return
    }

    if($Global:Settings.AskConfirmation)
    {
        Write-Host ""

        if(-not (Confirm-YesNo "plan.confirmMove"))
        {
            Write-Host ""
            Write-Host "==========================================" -ForegroundColor Yellow
            Write-Host (T "plan.operationCancelled") -ForegroundColor Yellow
            Write-Host (T "plan.operationCancelledDetail" $plan.TotalMove) -ForegroundColor Yellow
            Write-Host "==========================================" -ForegroundColor Yellow
            Write-Host ""
            return
        }
    }

    #--------------------------------------------------------------
    # Ejecución
    #--------------------------------------------------------------

    Invoke-CleanExecute $plan

    #--------------------------------------------------------------
    # Reexportar el plan tras ejecutar
    #
    # El primer Export-CleanPlan (más arriba) se hace ANTES de
    # mover nada, para que quede un registro aunque el usuario
    # cancele. Pero en ese momento todavía no sabemos qué archivos
    # asociados se movieron de verdad con cada ROM (eso se decide
    # durante Invoke-CleanExecute). Sin este segundo export,
    # "Deshacer la última limpieza" nunca podría restaurar esos
    # archivos asociados, porque CleanPlan.json se habría quedado
    # con la versión "antes de ejecutar".
    #--------------------------------------------------------------

    Export-CleanPlan `
        -Plan $plan `
        -OutputFolder (Join-Path $Root "Resultado") |
        Out-Null

}

function Invoke-CleanPreview {

    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$Groups,

        [Parameter(Mandatory)]
        [string]$Root
    )

    #
    # Se calculan de golpe (y en paralelo si hay suficientes) los
    # hashes de TODAS las ROMs que van a necesitar una acción
    # (todos los miembros de todos los grupos), en vez de ir
    # hasheando una a una según se construye cada acción más
    # abajo. Con colecciones grandes, esto es lo que más tiempo
    # ahorra de toda la limpieza.
    #

    $allPaths = @(
        $Groups | ForEach-Object { $_.Roms } | ForEach-Object { $_.FullPath }
    )

    $hashLookup = Get-RomHashesParallel -Paths $allPaths

    $actions = @()

    foreach($group in $Groups)
    {
        foreach($r in $group.Roms)
        {
            Write-Host " -" $r.Title
        }

        Write-Host ""
        Write-Host "===================================="
        Write-Host (T "group.label") $group.Name
        Write-Host (T "group.romCount") $group.Roms.Count

        #
        # Decision Engine
        #

        $decision = Decide-RomGroup $group.Roms

        if($null -eq $decision)
        {
            continue
        }

        #
        # KEEP
        #

        $actions += New-CleanAction `
            -Action "KEEP" `
            -Rom $decision.Keep `
            -Reason ($decision.KeepReason -join "`n") `
            -Hash $hashLookup[$decision.Keep.FullPath] `
            -System $group.System

        #
        # MOVE
        #

        foreach($item in $decision.MoveReasons)
        {
            $target = Get-DuplicateTargetFolder -SystemName $group.System

            $actions += New-CleanAction `
                -Action "MOVE" `
                -Rom $item.Rom `
                -Target $target `
                -Reason ($item.Reason -join "`n") `
                -Hash $hashLookup[$item.Rom.FullPath] `
                -System $group.System
        }
    }

    return $actions

}

# ============================================================
# Obtener estadísticas del plan
# ============================================================

function Get-CleanStatistics {

    param(
        [Parameter(Mandatory)]
        $Plan
    )

    #
    # BUG corregido en la v2.6: si todas las acciones pertenecen a
    # UN SOLO sistema (el caso más habitual: limpiar un sistema
    # concreto, no "0) TODOS LOS SISTEMAS"), la tubería de arriba
    # devuelve un texto suelto, no un array de un elemento — así
    # es como funciona PowerShell con resultados de un solo
    # elemento. Bajo Set-StrictMode -Version Latest (activo desde
    # que se carga DecisionEngine.ps1), un texto suelto NO tiene
    # una propiedad .Count de verdad, así que $systems.Count más
    # abajo lanzaba "la propiedad Count no existe" y rompía el
    # resumen de CUALQUIER limpieza de un solo sistema. Envolver
    # en @() garantiza que $systems sea siempre un array, tenga
    # 0, 1 o más sistemas.
    #

    $systems = @(
        $Plan.Actions |
            ForEach-Object {
                if([string]::IsNullOrWhiteSpace($_.System))
                {
                    Split-Path (Split-Path $_.Source -Parent) -Leaf
                }
                else
                {
                    $_.System
                }
            } |
            Sort-Object -Unique
    )

    return [PSCustomObject]@{

        TotalActions = $Plan.TotalActions

        KeepCount = $Plan.TotalKeep

        MoveCount = $Plan.TotalMove

        DeleteCount = $Plan.TotalDelete

        RenameCount = $Plan.TotalRename

        SystemCount = $systems.Count

		Systems = $systems

        BuildDate = $Plan.BuildDate

        Version = $Plan.Version

    }

}

# ============================================================
# Mostrar vista previa
# ============================================================

function Show-CleanPreview {

    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$Actions
    )

    Write-Host ""
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host (T "plan.previewTitle")
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host ""

    if($Global:Settings.PreviewOnly)
    {
        Write-Host (T "plan.previewOnlyNotice") -ForegroundColor DarkYellow
        Write-Host ""
    }

    foreach($action in $Actions)
    {
        switch($action.Action)
        {
            "KEEP"
            {
                Write-Host "[KEEP]" -ForegroundColor Green
            }

            "MOVE"
            {
                Write-Host "[MOVE]" -ForegroundColor Yellow
            }

            "DELETE"
            {
                Write-Host "[DELETE]" -ForegroundColor Red
            }

            default
            {
                Write-Host "[$($action.Action)]"
            }
        }

        Write-Host $action.Source

        if($action.Target)
        {
            Write-Host (T "plan.destination" $action.Target)
        }

        Write-Host (T "plan.reason")
        Write-Host $action.Reason

        if($action.Hash)
        {
            Write-Host (T "plan.hash" @($Global:Settings.HashAlgorithm, $action.Hash))
        }

        Write-Host ""
    }
}

# ============================================================
# Construye el plan completo de limpieza
# ============================================================

function Build-CleanPlan {

    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$Actions
    )

    $plan = [PSCustomObject]@{

        Actions = $Actions

        KeepActions = @(
            $Actions | Where-Object Action -eq "KEEP"
        )

        MoveActions = @(
            $Actions | Where-Object Action -eq "MOVE"
        )

        DeleteActions = @(
            $Actions | Where-Object Action -eq "DELETE"
        )

        RenameActions = @(
            $Actions | Where-Object Action -eq "RENAME"
        )

    }

    #
    # Totales
    #

    $plan | Add-Member NoteProperty TotalKeep   $plan.KeepActions.Count
    $plan | Add-Member NoteProperty TotalMove   $plan.MoveActions.Count
    $plan | Add-Member NoteProperty TotalDelete $plan.DeleteActions.Count
    $plan | Add-Member NoteProperty TotalRename $plan.RenameActions.Count
	$plan | Add-Member NoteProperty TotalActions $Actions.Count
	$plan | Add-Member NoteProperty BuildDate (Get-Date)
	$plan | Add-Member NoteProperty Version "CleanROMs v2.7"

    return $plan

}

# ============================================================
# Valida el plan antes de ejecutarlo
# ============================================================

function Validate-CleanPlan {

    param(
        [Parameter(Mandatory)]
        $Plan
    )

    #
    # No puede haber dos KEEP del mismo archivo
    #

    $duplicates = @(
        $Plan.KeepActions |
            Group-Object Source |
            Where-Object Count -gt 1
    )

    if($duplicates.Count -gt 0)
    {
        throw "El plan contiene acciones KEEP duplicadas."
    }

    #
    # Una acción MOVE necesita destino
    #

    foreach($action in $Plan.MoveActions)
    {
        if([string]::IsNullOrWhiteSpace($action.Target))
        {
            throw "Acción MOVE sin destino: $($action.Source)"
        }
    }

    return $true

}

# ============================================================
# Exporta el plan de limpieza
# ============================================================

function Export-CleanPlan {

    param(

        [Parameter(Mandatory)]
        $Plan,

        [Parameter(Mandatory)]
        [string]$OutputFolder,

        #
        # Solo se indica en el primer export de cada ejecución de
        # "Limpiar ROMs duplicadas" (antes de tocar nada), que es
        # cuando de verdad empieza una limpieza nueva. El segundo
        # export (después de ejecutar, para anotar los archivos
        # asociados) NO debe rotar nada: sigue siendo la MISMA
        # sesión, solo se está actualizando su registro final.
        #

        [switch]$Rotate

    )

    if(!(Test-Path -LiteralPath $OutputFolder))
    {
        New-Item -ItemType Directory -Path $OutputFolder | Out-Null
    }

    $jsonFile = Join-Path $OutputFolder "CleanPlan.json"

    $csvFile = Join-Path $OutputFolder "CleanPlan.csv"

    $htmlFile = Join-Path $OutputFolder "CleanPlan.html"

    if($Rotate)
    {
        Move-CleanPlanToHistory -OutputFolder $OutputFolder
    }

    #
    # JSON completo
    #

    $Plan.Actions |
        ConvertTo-Json -Depth 10 |
        Set-Content $jsonFile -Encoding UTF8

    #
    # CSV resumido
    #

    $Plan.Actions |
        Select-Object `
            Action,
            Source,
            Target,
            Reason,
            @{Name = $Global:Settings.HashAlgorithm; Expression = { $_.Hash }} |
        Export-Csv `
            -Path $csvFile `
            -NoTypeInformation `
            -Encoding UTF8

    #
    # Informe HTML (para abrir con doble clic y revisar cómodamente)
    #

    New-CleanPlanHtmlReport -Plan $Plan |
        Set-Content $htmlFile -Encoding UTF8

    return [PSCustomObject]@{

        Json = $jsonFile

        Csv  = $csvFile

        Html = $htmlFile

    }

}

# ============================================================
# Añade acciones MOVE al CleanPlan.json ya existente, sin tocar
# lo que ya había.
#
# La usan Invoke-HackOrganizer e Invoke-HackDeduplication
# (HackOrganizer.ps1) para que sus movimientos —organizar hacks
# sueltos en "# Hacks y Otros #", y mover sus duplicados exactos a
# _duplicates— también los cubra "Deshacer la última limpieza",
# igual que los movimientos de la limpieza normal de ROMs.
#
# Solo actualiza el JSON (lo que de verdad lee UndoManager.ps1),
# no el CSV ni el HTML: esos son el informe de "qué se hizo en la
# limpieza normal de ROMs", un concepto distinto.
# ============================================================

function Add-CleanPlanEntries {

    param(

        [Parameter(Mandatory)]
        [string]$Root,

        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$NewActions

    )

    if($NewActions.Count -eq 0)
    {
        return
    }

    $outputFolder = Join-Path $Root "Resultado"

    if(!(Test-Path -LiteralPath $outputFolder))
    {
        New-Item -ItemType Directory -Path $outputFolder | Out-Null
    }

    $jsonFile = Join-Path $outputFolder "CleanPlan.json"

    $existingActions = @()

    if(Test-Path -LiteralPath $jsonFile)
    {
        try
        {
            $existingActions = @(Get-Content -LiteralPath $jsonFile -Raw | ConvertFrom-Json)
        }
        catch
        {
            #
            # Si el archivo existente está dañado, mejor no
            # arriesgarse a perder las acciones nuevas: se
            # continúa como si no hubiera nada previo.
            #

            $existingActions = @()
        }
    }

    $allActions = @($existingActions) + @($NewActions)

    $allActions |
        ConvertTo-Json -Depth 10 |
        Set-Content $jsonFile -Encoding UTF8

}

# ============================================================
# Mueve el CleanPlan.json actual (si existe) a
# Resultado\History\, con marca de tiempo en el nombre, antes de
# que empiece a escribirse uno nuevo. Así "Deshacer la última
# limpieza" puede ofrecer no solo la más reciente, sino también
# sesiones anteriores.
#
# Solo se llama al EMPEZAR una limpieza nueva (Export-CleanPlan
# -Rotate), nunca al reexportar la misma sesión ya en curso.
#
# También recorta el historial a
# $Global:Settings.UndoHistoryLimit archivos, borrando los más
# antiguos si hace falta, para que la carpeta no crezca sin límite.
# ============================================================

function Move-CleanPlanToHistory {

    param(
        [Parameter(Mandatory)]
        [string]$OutputFolder
    )

    $currentJson = Join-Path $OutputFolder "CleanPlan.json"

    if(!(Test-Path -LiteralPath $currentJson))
    {
        #
        # No había ninguna limpieza previa (primera vez que se
        # ejecuta el programa, o Resultado\ recién creada) — no
        # hay nada que archivar todavía.
        #

        return
    }

    $historyFolder = Join-Path $OutputFolder "History"

    if(!(Test-Path -LiteralPath $historyFolder))
    {
        New-Item -ItemType Directory -Path $historyFolder | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

    $historyFile = Join-Path $historyFolder "CleanPlan_$timestamp.json"

    #
    # Por si dos rotaciones cayeran en el mismo segundo (poco
    # probable, pero gratis evitarlo): se añade un sufijo hasta
    # encontrar un nombre libre.
    #

    $suffix = 1

    while(Test-Path -LiteralPath $historyFile)
    {
        $historyFile = Join-Path $historyFolder "CleanPlan_$timestamp`_$suffix.json"
        $suffix++
    }

    Copy-Item -LiteralPath $currentJson -Destination $historyFile

    #
    # Recorte del historial
    #

    $limit = $Global:Settings.UndoHistoryLimit

    if($null -eq $limit -or $limit -lt 0)
    {
        $limit = 10
    }

    $existing = @(
        Get-ChildItem -LiteralPath $historyFolder -Filter "CleanPlan_*.json" |
            Sort-Object LastWriteTime -Descending
    )

    if($existing.Count -gt $limit)
    {
        $toDelete = $existing | Select-Object -Skip $limit

        foreach($old in $toDelete)
        {
            Remove-Item -LiteralPath $old.FullName -Force -ErrorAction SilentlyContinue
        }
    }

}

# ============================================================
# Generar el informe HTML del plan de limpieza
# ============================================================

function New-CleanPlanHtmlReport {

    param(

        [Parameter(Mandatory)]
        $Plan

    )

    function Convert-HtmlSafe($Text)
    {
        if([string]::IsNullOrEmpty($Text))
        {
            return ""
        }

        return [System.Net.WebUtility]::HtmlEncode($Text)
    }

    $rows = ""

    foreach($action in $Plan.Actions)
    {
        $rowClass = switch($action.Action)
        {
            "KEEP"   { "keep" }
            "MOVE"   { "move" }
            "DELETE" { "delete" }
            "RENAME" { "rename" }
            default  { "" }
        }

        $source = Convert-HtmlSafe $action.Source
        $target = Convert-HtmlSafe $action.Target
        $reason = Convert-HtmlSafe ($action.Reason -replace "`n", " · ")
        $hash   = Convert-HtmlSafe $action.Hash

        $rows += "<tr class=`"$rowClass`"><td>$($action.Action)</td><td>$source</td><td>$target</td><td>$reason</td><td class=`"hash`">$hash</td></tr>`n"
    }

    $keepCount   = @($Plan.Actions | Where-Object { $_.Action -eq "KEEP" }).Count
    $moveCount   = @($Plan.Actions | Where-Object { $_.Action -eq "MOVE" }).Count
    $deleteCount = @($Plan.Actions | Where-Object { $_.Action -eq "DELETE" }).Count
    $renameCount = @($Plan.Actions | Where-Object { $_.Action -eq "RENAME" }).Count

    $date = Get-Date -Format "dd/MM/yyyy HH:mm:ss"

    $html = @"
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>CleanROMs - Informe de limpieza</title>
<style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background:#f4f6f8; color:#222; margin:0; padding:24px; }
    h1 { color:#1b3a5c; margin-bottom:4px; }
    .meta { color:#666; margin-bottom:20px; }
    .stats { display:flex; gap:14px; margin-bottom:22px; flex-wrap:wrap; }
    .stat { background:#fff; border-radius:8px; padding:10px 22px; box-shadow:0 1px 3px rgba(0,0,0,0.12); min-width:100px; text-align:center; }
    .stat .n { font-size:22px; font-weight:bold; display:block; }
    .stat.keep .n   { color:#2e7d32; }
    .stat.move .n   { color:#b8860b; }
    .stat.delete .n { color:#c62828; }
    .stat.rename .n { color:#1565c0; }
    table { width:100%; border-collapse:collapse; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,0.1); }
    th, td { padding:7px 10px; text-align:left; border-bottom:1px solid #e5e5e5; font-size:12.5px; word-break:break-all; }
    th { background:#1b3a5c; color:#fff; position:sticky; top:0; }
    tr.keep td:first-child   { color:#2e7d32; font-weight:bold; }
    tr.move td:first-child   { color:#b8860b; font-weight:bold; }
    tr.delete td:first-child { color:#c62828; font-weight:bold; }
    tr.rename td:first-child { color:#1565c0; font-weight:bold; }
    tr:hover { background:#f0f4f8; }
    td.hash { font-family: Consolas, 'Courier New', monospace; font-size:11px; color:#555; }
</style>
</head>
<body>
    <h1>CleanROMs &mdash; Informe de limpieza</h1>
    <div class="meta">Generado: $date</div>
    <div class="stats">
        <div class="stat keep"><span class="n">$keepCount</span>KEEP</div>
        <div class="stat move"><span class="n">$moveCount</span>MOVE</div>
        <div class="stat delete"><span class="n">$deleteCount</span>DELETE</div>
        <div class="stat rename"><span class="n">$renameCount</span>RENAME</div>
    </div>
    <table>
        <thead>
            <tr><th>Acción</th><th>Archivo</th><th>Destino</th><th>Motivo</th><th>$($Global:Settings.HashAlgorithm)</th></tr>
        </thead>
        <tbody>
$rows
        </tbody>
    </table>
</body>
</html>
"@

    return $html

}

# ============================================================
# Obtener carpeta destino de duplicados
# ============================================================

function Get-DuplicateTargetFolder {

    param(
        #
        # Antes se calculaba el "nombre del sistema" haciendo
        # Split-Path dos veces sobre $Rom.FullPath, asumiendo que la
        # ROM vive siempre justo dentro de la carpeta del sistema.
        # Eso se rompía en cuanto la ROM vivía un nivel más adentro
        # (p.ej. dentro de "# Hacks y Otros #"): el "sistema"
        # calculado terminaba siendo "# Hacks y Otros #", y las
        # ROMs acababan en "_duplicates\# Hacks y Otros #\" en vez
        # de "_duplicates\<sistema real>\". Ahora el nombre del
        # sistema se recibe explícito desde quien sí lo conoce con
        # certeza (el bucle que recorre $Global:Settings.SystemFolders).
        #

        [Parameter(Mandatory)]
        [string]$SystemName
    )

    $target = Join-Path `
        (Join-Path $Global:RetroBatRoot $Global:DuplicatesFolder) `
        $SystemName

    return $target

}


