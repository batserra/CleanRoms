﻿# ============================================================
# CleanROMs
#
# Executor.ps1
#
# Ejecuta el plan de limpieza
# ============================================================

function Invoke-CleanExecute {

    param(

        [Parameter(Mandatory)]
        $Plan

    )
	
	$keepCount = 0

$moveCount = 0

$deleteCount = 0

$renameCount = 0

$movedOkCount = 0

$previewCount = 0

$skippedMissingCount = 0

$skippedExistsCount = 0

    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host (T "exec.executing")
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

$total = $Plan.Actions.Count

$index = 0

foreach($action in $Plan.Actions)
{
    $index++
	
	switch($action.Action)
{
    "KEEP"   {$keepCount++}
    "MOVE"   {$moveCount++}
    "DELETE" {$deleteCount++}
    "RENAME" {$renameCount++}
}

    Write-Progress `
        -Activity (T "exec.progress") `
        -Status (T "progress.status" @($index, $total)) `
        -PercentComplete (($index / $total) * 100)

     try
    {
        $result = Invoke-CleanAction $action

        if($action.Action -eq "MOVE")
        {
            switch($result)
            {
                "MOVED"            { $movedOkCount++ }
                "PREVIEW"          { $previewCount++ }
                "SKIPPED_MISSING"  { $skippedMissingCount++ }
                "SKIPPED_EXISTS"   { $skippedExistsCount++ }
            }
        }
    }
    catch
    {
        Write-Warning $_

        Write-Log "ERROR: $($_.Exception.Message)"

        $Global:ActionErrorCount = [int]$Global:ActionErrorCount + 1
    }
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan

Write-Host ("KEEP    : {0}" -f $keepCount) `
    -ForegroundColor Green

Write-Host ("MOVE    : {0}" -f $moveCount) `
    -ForegroundColor Yellow

if($movedOkCount -gt 0)
{
    Write-Host (T "exec.movedOk" $movedOkCount) `
        -ForegroundColor Yellow
}

if($previewCount -gt 0)
{
    Write-Host (T "exec.previewOnly" $previewCount) `
        -ForegroundColor DarkYellow
}

if($skippedExistsCount -gt 0)
{
    Write-Host (T "exec.skippedExists" $skippedExistsCount) `
        -ForegroundColor Red
}

if($skippedMissingCount -gt 0)
{
    Write-Host (T "exec.skippedMissing" $skippedMissingCount) `
        -ForegroundColor Red
}

Write-Host ("DELETE  : {0}" -f $deleteCount) `
    -ForegroundColor Red

Write-Host ("RENAME  : {0}" -f $renameCount) `
    -ForegroundColor Cyan

Write-Host "==========================================" -ForegroundColor Cyan


Write-Progress `
    -Activity (T "exec.progress") `
    -Completed

    Write-Host ""
    Write-Host (T "exec.planCompleted")
}

function Invoke-CleanAction {

    param(

        [Parameter(Mandatory)]
        $Action

    )

    switch($Action.Action)
    {

        "KEEP"
        {
            Invoke-KeepAction $Action
            return "KEPT"
        }

        "MOVE"
        {
            return Invoke-MoveAction $Action
        }

        "DELETE"
        {
            Invoke-DeleteAction $Action
            return "DELETED"
        }

        "RENAME"
        {
            Invoke-RenameAction $Action
            return "RENAMED"
        }

        default
        {
            throw (T "exec.unknownAction" $Action.Action)
        }

    }

}

function Invoke-KeepAction {

    param($Action)

    Write-Host "[KEEP ] $($Action.Source)" -ForegroundColor Green

}

# ============================================================
# Ejecutar acción MOVE
# ============================================================

function Invoke-MoveAction {

    param(
        [Parameter(Mandatory)]
        $Action
    )

    #
    # Comprobaciones
    #

    if(!(Test-Path -LiteralPath $Action.Source))
    {
        Write-Warning (T "exec.fileNotFound")
        Write-Warning $Action.Source
        return "SKIPPED_MISSING"
    }

    #
    # Crear carpeta destino
    #

    if(!(Test-Path -LiteralPath $Action.Target))
    {
        New-Item `
            -ItemType Directory `
            -Path $Action.Target `
            -Force | Out-Null
    }

    #
    # Destino completo
    #

    $destination = Join-Path `
        $Action.Target `
        (Split-Path $Action.Source -Leaf)

    #
    # Evitar sobrescribir
    #

    if(Test-Path -LiteralPath $destination)
    {
        Write-Warning (T "exec.alreadyExists")
        Write-Warning $destination
        return "SKIPPED_EXISTS"
    }

    #
    # Movimiento
    #
	
	#
# Modo simulación
#

if($Global:Settings.PreviewOnly)
{
    Write-Host (T "exec.previewMove" $Action.Source) -ForegroundColor DarkYellow
    return "PREVIEW"
}



    Move-Item `
        -LiteralPath $Action.Source `
        -Destination $destination

    Write-Host "[MOVE ] $($Action.Source)" -ForegroundColor Yellow

    #
    # Mover también los archivos asociados a esta ROM (guardado,
    # configuración de mando, etc. con el mismo nombre): sin esto
    # se quedan huérfanos en la carpeta original, apuntando a una
    # ROM que ya no está ahí.
    #

    if($Global:Settings.MoveAssets)
    {
        $assets = Get-AssociatedFiles $Action.Rom

        foreach($asset in $assets)
        {
            try
            {
                Move-Asset -Asset $asset -TargetFolder $Action.Target
                Write-Host "[MOVE ]   + $($asset.Name)" -ForegroundColor DarkYellow

                #
                # Se anota aquí (no al crear la acción) porque hasta
                # este momento no sabíamos con certeza qué archivos
                # asociados existían de verdad ni si el movimiento
                # iba a funcionar. Sin esto, "Deshacer la última
                # limpieza" nunca podría devolver estos archivos a
                # su sitio.
                #

                $Action.AssociatedFiles += $asset.Name
            }
            catch
            {
                Write-Warning (T "exec.assetMoveFailed" @($asset.FullName, $_.Exception.Message))
            }
        }
    }

    return "MOVED"

}

function Invoke-DeleteAction {

    param(
        [Parameter(Mandatory)]
        $Action
    )

    if($Global:Settings.PreviewOnly)
    {
        Write-Host (T "exec.previewDelete" $Action.Source) -ForegroundColor DarkRed
        return
    }

    Write-Host "[DELETE] $($Action.Source)" -ForegroundColor Red

    Remove-Item `
        -LiteralPath $Action.Source `
        -Force

    if($Global:Settings.MoveAssets)
    {
        $assets = Get-AssociatedFiles $Action.Rom

        foreach($asset in $assets)
        {
            try
            {
                Remove-Item -LiteralPath $asset.FullName -Force
                Write-Host "[DELETE]   + $($asset.Name)" -ForegroundColor DarkRed
            }
            catch
            {
                Write-Warning (T "exec.assetDeleteFailed" $asset.FullName)
            }
        }
    }
}

function Invoke-RenameAction {

    param(
        [Parameter(Mandatory)]
        $Action
    )

    if($Global:Settings.PreviewOnly)
    {
        Write-Host (T "exec.previewRename" $Action.Source) -ForegroundColor Cyan
        return
    }

    Write-Host "[RENAME] $($Action.Source)" -ForegroundColor Cyan

    Rename-Item `
        -LiteralPath $Action.Source `
        -NewName $Action.Target

}




